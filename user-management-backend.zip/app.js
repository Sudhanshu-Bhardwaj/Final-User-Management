require("dotenv").config();
const express = require("express");
const app = express();
const userRouter = require("./api/users/user.router");
var cors = require('cors');

const swaggerUi = require("swagger-ui-express");
swaggerDocument = require("./swagger.json");

app.use(express.json());

// CORS Headers Middleware
app.use(cors({
  origin: '*'
}));

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

app.use("/api/users", userRouter);
const port = process.env.APP_PORT;
app.listen(port, () => {
  console.log("server up and running on PORT :", port);
});