const router = require("express").Router();
const { checkToken } = require("../../auth/token_validation");
const {
  createUser,
  login,
  getUserByUserId,
  getUsers,
  updateUsers,
  updateUser,
  deleteUser
} = require("./user.controller");
router.get("/getUsers",  getUsers);
router.post("/addUser",  createUser);
router.get("/getUserById/:id", getUserByUserId);
router.post("/login", login);
router.put("/updateUsers", updateUsers);
router.patch("/updateUser", updateUser);
router.delete("/deleteUser/:id", deleteUser);

module.exports = router;